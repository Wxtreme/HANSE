﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class Discovery : NetworkDiscovery
{
    void Start()
    {
        broadcastData = PlayerPrefs.GetString("username");
    }
	
	public void StartServer()
    {
        Initialize();
        StartAsServer();
        Utils.LoadScene("server");
    }

    public void StartClient()
    {
        Initialize();
        StartAsClient();
        Button serverBtn = GameObject.Find("Start as server").GetComponent<Button>();
        serverBtn.interactable = false;
    }

    public override void OnReceivedBroadcast(string fromAddress, string data)
    {
        Debug.Log("discovered: " + data + "@" + fromAddress);
        PlayerPrefs.SetString("ip", fromAddress);
        Utils.LoadScene("client");
        Destroy(gameObject);
    }
}
