﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour {

    public Button playerButton;
    public Canvas canvas;
    public GameObject tradeDealPanel;
    public Text resourcesText;
    public Text narrator;
    public Button readyButton;
    public Sprite[] buttons;

    public float buttonDistanceMultiplier = 300;

    public string selectedPlayer;
    public string playerName;

    public ClientController clientController;
    public ServerController serverController;
    public bool isServer;

    public string[] players;
    int[] actualSend;
    int[] resources = new int[0];
    bool isReady = false;

    int lastPrintedTime;

	void Start () {
        try{ serverController = GameObject.Find("_ServerMaster").GetComponent<ServerController>(); }
        catch (NullReferenceException e){ }
        isServer = serverController != null;
        if (isServer)
        {
            serverController.Initialise();
        }

        try { clientController = GameObject.Find("_ClientMaster").GetComponent<ClientController>(); }
        catch (NullReferenceException e) { }
        if (!isServer)
        {
            clientController.Initialise();
        }
    }

    public void Initialise(string[] newPlayers, string me, int[] newResources)
    {
        playerName = me;
        players = newPlayers;
        resources = newResources;
        resourcesText.text = "Resources: \n";
        for (int i = 0; i < resources.Length; i++)
        {
            resourcesText.text += ResourceTypes.resources[i] + ": " + resources[i] + "\n";
        }
        actualSend = new int[players.Length - 1];
        for (int i = 0; i < newPlayers.Length; i++)
        {
            Button button = Instantiate(playerButton);
            button.transform.SetParent(canvas.transform);
            button.GetComponent<RectTransform>().localScale = Vector3.one;
            float angle = (Mathf.PI * 2) / newPlayers.Length;
            button.GetComponent<RectTransform>().localPosition =
                Utils.AngleToVector((-angle * i) + (Mathf.PI / 2) + (angle * Utils.PlayerNameToIndex(me, newPlayers)), buttonDistanceMultiplier);
            button.transform.GetChild(0).GetComponent<Text>().text = ResourceTypes.resources[i];
            button.transform.GetChild(1).GetComponent<Text>().text = newPlayers[i];
            button.GetComponent<Image>().sprite = buttons[i % buttons.Length];
            button.name = newPlayers[i];
            if (button.name == me)
            {
                button.transform.GetChild(0).GetComponent<Text>().color = Color.white;
                button.transform.GetChild(1).GetComponent<Text>().color = Color.white;
            }
            button.GetComponent<Button>().onClick.AddListener(delegate {
                if (me != button.name)
                {
                    GameObject panel = Instantiate(tradeDealPanel);
                    panel.transform.SetParent(canvas.transform);
                    panel.transform.localScale = Vector3.one;
                    selectedPlayer = button.name;
                }
            });
        }
        Utils.AddText(narrator, "The game begins...");
        Utils.AddText(narrator, "Your unique resource is: " + ResourceTypes.resources[Utils.PlayerNameToIndex(playerName, players)]);
    }

    public void Offer(Deal deal)
    {
        if (isServer)
        {
            serverController.Offer(deal);
        }
        else
        {
            clientController.Offer(deal);
        }
    }

    public void Respond(bool accept)
    {
        if (isServer)
        {
            serverController.Respond(playerName, selectedPlayer, accept);
        }
        else
        {
            clientController.Respond(selectedPlayer, accept);
        }
    }

    public Deal GetCurrentOffer()
    {
        if (isServer)
        {
            return serverController.GetCurrentOffer(selectedPlayer, playerName);
        }
        else
        {
            return clientController.GetCurrentOffer(selectedPlayer);
        }
    }

    public Deal GetCurrentDeal()
    {
        if (isServer)
        {
            return serverController.GetCurrentDeal(selectedPlayer, playerName);
        }
        else
        {
            return clientController.GetCurrentDeal(selectedPlayer);
        }
    }

    public Deal GetCurrentDeal(string player)
    {
        if (isServer)
        {
            return serverController.GetCurrentDeal(player, playerName);
        }
        else
        {
            return clientController.GetCurrentDeal(player);
        }
    }

    public void SetActualSend(int amount)
    {
        actualSend[Utils.PlayerNameToActualSendIndex(selectedPlayer, actualSend, players, playerName)] = amount;
        if (isServer)
        {
            serverController.SetActualSend(playerName, actualSend);
        }
        else
        {
            clientController.SetActualSend(actualSend);
        }
    }

    public int GetActualSend()
    {
        return actualSend[Utils.PlayerNameToActualSendIndex(selectedPlayer, actualSend, players, playerName)];
    }

    public void UpdateResources(int[] newResources, int[] deltaResources)
    {
        /*for (int i = 0; i < deltaResources.Length; i++)
        {
            if (deltaResources[i] > 0)
            {
                Utils.AddText(narrator, "You recieved: " + deltaResources[i] + " units of " + ResourceTypes.resources[i]);
            }
        }*/

        readyButton.GetComponentInChildren<Text>().color = Color.red;
        isReady = false;

        newResources.CopyTo(resources, 0);
        resourcesText.text = "Resources: \n";
        for (int i = 0; i < resources.Length; i++)
        {
            resourcesText.text += ResourceTypes.resources[i] + ": " + resources[i] + "\n";
        }
    }

    public void End(string[] leaderboard)
    {
        Utils.AddText(narrator, "");
        Utils.AddText(narrator, "");
        Utils.AddText(narrator, "Game ended");
        Utils.AddText(narrator, "");
        Utils.AddText(narrator, "Results:");
        for (int i = 0; i < leaderboard.Length; i++)
        {
            Utils.AddText(narrator, (i + 1) + ". " + leaderboard[i]);
        }
    }

    public void SetReady()
    {
        isReady = !isReady;
        if (isReady)
        {
            readyButton.GetComponentInChildren<Text>().color = Color.green;
        }
        else
        {
            readyButton.GetComponentInChildren<Text>().color = Color.red;
        }

        if (isServer)
        {
            serverController.SetReady(isReady, playerName);
        }
        else
        {
            clientController.SetReady(isReady);
        }
    }
}
