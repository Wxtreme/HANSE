﻿using UnityEngine;
using UnityEngine.UI;

public class TheirOfferController : MonoBehaviour {

    GameController gameController;

    Text recieve;
    Text send;
    Button acceptButton;
    Button declineButton;

    void Start()
    {
        gameController = GameObject.Find("_GameMaster").GetComponent<GameController>();
        recieve = transform.Find("Recieve text").GetComponent<Text>();
        send = transform.Find("Send text").GetComponent<Text>();
        acceptButton = transform.Find("Accept button").GetComponent<Button>();
        declineButton = transform.Find("Decline button").GetComponent<Button>();

        acceptButton.onClick.AddListener(delegate {
            gameController.Respond(true);
        });
        declineButton.onClick.AddListener(delegate {
            gameController.Respond(false);
        });
    }

    void Update()
    {
        Deal deal = gameController.GetCurrentOffer();

        int recieveInt = deal.player2to1;
        int sendInt = deal.player1to2;


        if (recieveInt != -1 && sendInt != -1)
        {
            recieve.text = "You recieve: \n" + recieveInt;
            send.text = "You send: \n" + sendInt;
        }
        else
        {
            recieve.text = "You recieve: \n" + "nothing";
            send.text = "You send: \n" + "nothing";
        }
    }
}
