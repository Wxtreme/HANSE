﻿using UnityEngine;
using UnityEngine.UI;

public class SyncSlider : MonoBehaviour {

    float max = 200;
    InputField input;
    Slider slider;

	void Start () {
        slider = GetComponent<Slider>();
        input = GetComponentInChildren<InputField>();
        OnInputValueChanged();

        slider.onValueChanged.AddListener(delegate { OnSliderValueChanged(); });
        input.onEndEdit.AddListener(delegate { OnInputValueChanged(); });
	}

    void OnSliderValueChanged()
    {
        input.text = ((Mathf.Round((slider.value * max) / 10) * 10)).ToString();
    }

    void OnInputValueChanged()
    {
        float value = int.Parse(input.text);
        if (value < 0)
        {
            value = 0;
        }
        if (value > max)
        {
            value = max;
        }
        input.text = ((int)value).ToString();
        value /= max;
        slider.value = value;
    }
}
