﻿using UnityEngine;
using UnityEngine.UI;

public class ClosePopupController : MonoBehaviour {

    GameObject gameMaster;

    void Start () {
        gameMaster = GameObject.Find("_GameMaster");

        GetComponent<Button>().onClick.AddListener(delegate {
            gameMaster.GetComponent<GameController>().selectedPlayer = "";
            GameObject parent = transform.parent.gameObject;
            Destroy(parent);
        });
    }
	
}
