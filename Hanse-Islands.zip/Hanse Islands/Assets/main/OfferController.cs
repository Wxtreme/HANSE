﻿using UnityEngine;
using UnityEngine.UI;

public class OfferController : MonoBehaviour {

    GameController gameController;

    InputField send;
    InputField recieve;
    Button button;

    void Start () {
        gameController = GameObject.Find("_GameMaster").GetComponent<GameController>();
        send = transform.Find("Send slider").Find("InputField").GetComponent<InputField>();
        recieve = transform.Find("Recieve slider").Find("InputField").GetComponent<InputField>();
        button = transform.Find("Offer button").GetComponent<Button>();

        button.onClick.AddListener(delegate {
            gameController.Offer(new Deal(gameController.playerName, int.Parse(send.text), gameController.selectedPlayer, int.Parse(recieve.text)));
        });
    }
}
