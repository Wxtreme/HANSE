﻿using UnityEngine;
using UnityEngine.UI;

public class CurrentDealController : MonoBehaviour {

    GameController gameController;

    Text recieve;
    Text send;

    void Start()
    {
        gameController = GameObject.Find("_GameMaster").GetComponent<GameController>();
        recieve = transform.Find("Recieve text").GetComponent<Text>();
        send = transform.Find("Send text").GetComponent<Text>();
    }

    void Update()
    {
        Deal deal = gameController.GetCurrentDeal();

        int recieveInt;
        int sendInt;

        if (gameController.playerName != deal.player1)
        {
            recieveInt = deal.player2to1;
            sendInt = deal.player1to2;
        }
        else
        {
            recieveInt = deal.player1to2;
            sendInt = deal.player2to1;
        }


        if (recieveInt != -1 && sendInt != 1)
        {
            recieve.text = "You recieve: \n" + recieveInt;
            send.text = "You send: \n" + sendInt;
        }
        else
        {
            recieve.text = "You recieve: \n" + "nothing";
            send.text = "You send: \n" + "nothing";
        }
    }
}
