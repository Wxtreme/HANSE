﻿using UnityEngine;
using UnityEngine.UI;

public class SendController : MonoBehaviour {

    GameController gameController;

    InputField send;
    Button button;

    void Start()
    {
        gameController = GameObject.Find("_GameMaster").GetComponent<GameController>();
        send = transform.Find("Send slider").Find("InputField").GetComponent<InputField>();
        button = transform.Find("Set button").GetComponent<Button>();
        send.text = gameController.GetActualSend().ToString();
        button.onClick.AddListener(delegate {
            gameController.SetActualSend(int.Parse(send.text));
        });
    }
}
