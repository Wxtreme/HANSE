﻿using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class ClientController : MonoBehaviour {

    public Text text;
    NetworkClient client;

    GameController gameController;

    public bool isGameStarted = false;

    string[] players;
    string playerName;
    int[] startResources;

    Deal[] offers;
    Deal[] deals;

    public void OnConnected(NetworkMessage netMsg)
    {
        ClientMessage msg = new ClientMessage(PlayerPrefs.GetString("username"));
        Debug.Log("MessageTypes.setup: " + MessageTypes.setup);
        client.Send(MessageTypes.setup, msg);
        text.text = "Waiting for server...";
    }

    public void OnDisconnected(NetworkMessage netMsg)
    {
        Debug.Log("Disconnected from server");
    }

    public void OnError(NetworkMessage netMsg)
    {
        Debug.Log("Error connecting");
    }

    public void Start()
    {
        client = new NetworkClient();

        client.RegisterHandler(MsgType.Connect, OnConnected);
        client.RegisterHandler(MsgType.Disconnect, OnDisconnected);
        client.RegisterHandler(MsgType.Error, OnError);
        client.RegisterHandler(MessageTypes.text, OnTextMessage);
        client.RegisterHandler(MessageTypes.start, OnStartMessage);
        client.RegisterHandler(MessageTypes.offersUpdate, OnOffersUpdate);
        client.RegisterHandler(MessageTypes.dealsUpdate, OnDealsUpdate);
        client.RegisterHandler(MessageTypes.resources, OnResourcesUpdate);

        client.Connect(PlayerPrefs.GetString("ip"), 7070);
    }

    void OnTextMessage(NetworkMessage netMsg)
    {
        TextMessage msg = netMsg.ReadMessage<TextMessage>();
        Debug.Log("Message: " + msg.text);
    }

    void OnStartMessage(NetworkMessage netMsg)
    {
        StartMessage msg = netMsg.ReadMessage<StartMessage>();
        isGameStarted = true;
        DontDestroyOnLoad(gameObject);
        Utils.LoadScene("game");
        Debug.Log("started game");
        players = msg.players;
        playerName = msg.player;
        startResources = msg.resources;
    }

    public void Initialise()
    {
        Debug.Log("initialise");
        gameController = GameObject.Find("_GameMaster").GetComponent<GameController>();
        gameController.Initialise(players, playerName, startResources);
    }

    public void Offer(Deal deal)
    {
        client.Send(MessageTypes.deal, deal);
    }

    public void Respond(string offerFrom, bool accept)
    {
        client.Send(MessageTypes.response, new Response(offerFrom, accept));
    }

    public void SetActualSend(int[] array)
    {
        client.Send(MessageTypes.actualSend, new ActualSend(array));
    }

    public void SetReady(bool isReady)
    {
        client.Send(MessageTypes.ready, new ReadyMessage(isReady));
    }

    public Deal GetCurrentOffer(string from)
    {
        for (int i = 0; i < offers.Length; i++)
        {
            if (offers[i].player1 == from && offers[i].player2 == playerName)
            {
                return offers[i];
            }
        }
        return new Deal(from, -1, playerName, -1);
    }

    public Deal GetCurrentDeal(string player)
    {
        for (int i = 0; i < deals.Length; i++)
        {
            if ((deals[i].player1 == player || deals[i].player2 == player) && (deals[i].player1 == playerName || deals[i].player2 == playerName))
            {
                return deals[i];
            }
        }
        return new Deal(player, -1, playerName, -1);
    }

    void OnOffersUpdate(NetworkMessage netMsg)
    {
        offers = netMsg.ReadMessage<DealArray>().array;
    }

    void OnDealsUpdate(NetworkMessage netMsg)
    {
        deals = netMsg.ReadMessage<DealArray>().array;
    }

    void OnResourcesUpdate(NetworkMessage netMsg)
    {
        Resources res = netMsg.ReadMessage<Resources>();
        for (int i = 0; i < res.resourcesDelta.Length; i++)
        {
            Debug.Log(res.resourcesDelta[i]);
        }
        gameController.UpdateResources(res.resources, res.resourcesDelta);
    }

    void OnEnd(NetworkMessage netMsg)
    {
        EndMessage end = netMsg.ReadMessage<EndMessage>();
        gameController.End(end.players);
    }
}
