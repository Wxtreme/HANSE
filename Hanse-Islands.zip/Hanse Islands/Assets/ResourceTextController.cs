﻿using UnityEngine;
using UnityEngine.UI;

public class ResourceTextController : MonoBehaviour {

    GameController gameController;

	void Start () {
        gameController = GameObject.Find("_GameMaster").GetComponent<GameController>();
        GetComponent<Text>().text = "Resource: " + ResourceTypes.resources[Utils.PlayerNameToIndex(gameController.selectedPlayer, gameController.players)];
	}
}
