﻿using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

using System.Collections.Generic;

public class ServerController : MonoBehaviour {

    public Text text;

    public bool isGameStarted = false;
    public bool isGameOver = false;

    List<Client> clients = new List<Client>();
    List<Player> players = new List<Player>();
    List<Deal> deals = new List<Deal>();
    List<Deal> offers = new List<Deal>();

    public GameController gameController;

    void Start()
    {
        NetworkServer.Listen(7070);
        NetworkServer.RegisterHandler(MsgType.Connect, OnConnected);
        NetworkServer.RegisterHandler(MsgType.Disconnect, OnDisconnected);
        NetworkServer.RegisterHandler(MsgType.Error, OnError);
        NetworkServer.RegisterHandler(MessageTypes.text, OnTextMessage);
        NetworkServer.RegisterHandler(MessageTypes.setup, OnSetup);
        NetworkServer.RegisterHandler(MessageTypes.deal, OnOffer);
        NetworkServer.RegisterHandler(MessageTypes.response, OnResponse);
        NetworkServer.RegisterHandler(MessageTypes.actualSend, OnSetSend);
        NetworkServer.RegisterHandler(MessageTypes.ready, OnReady);
    }

    void OnConnected(NetworkMessage netMsg)
    {
        Debug.Log("Client connected on connection id: " + netMsg.conn.connectionId.ToString());
    }

    public void OnDisconnected(NetworkMessage netMsg)
    {
        Debug.Log(FindPlayerName(netMsg.conn.connectionId) + " disconnected from server");
        if (!isGameStarted)
        {
            RemovePlayer(netMsg.conn.connectionId);
            UpdatePlayerList();
        }
    }

    public void OnError(NetworkMessage netMsg)
    {
        Debug.Log("Error");
    }

    void OnSetup(NetworkMessage netMsg)
    {
        Debug.Log("netMsg.msgType " + netMsg.msgType);
        ClientMessage msg = netMsg.ReadMessage<ClientMessage>();
        clients.Add(new Client(msg.name, netMsg.conn.connectionId));
        Debug.Log("Name: " + msg.name);
        Debug.Log("ID: " + netMsg.conn.connectionId);
        UpdatePlayerList();
    }

    void OnTextMessage(NetworkMessage netMsg)
    {
        Debug.Log("netMsg.msgType " + netMsg.msgType);
        TextMessage msg = netMsg.ReadMessage<TextMessage>();

        Debug.Log("Message from " + FindPlayerName(netMsg.conn.connectionId) + ": " + msg.text);
    }

    string FindPlayerName(int id)
    {
        foreach (Client client in clients)
        {
            if (client.id == id)
            {
                return client.name;
            }
        }

        return "null";
    }

    int FindPlayerByName(string player)
    {
        for (int i = 0; i < players.Count; i++)
        {
            if (players[i].name == player)
            {
                return i;
            }
        }

        return -1;
    }

    void RemovePlayer(int id)
    {
        for (int i = 0; i < clients.Count; i++)
        {
            if (clients[i].id == id)
            {
                clients.RemoveAt(i);
            }
        }
    }

    void UpdatePlayerList()
    {
        if (text != null)
        {
            text.text = "";
            for (int i = 0; i < clients.Count; i++)
            {
                text.text += clients[i].name + "\n";
            }
        }
    }

    //--game
    public void StartGame()
    {
        Destroy(GameObject.Find("_DISCOVERY_MASTER"));
        isGameStarted = true;
        DontDestroyOnLoad(gameObject);
        //TODO: load after all clients respond with a ready message
        Utils.LoadScene("game");
    }

    public void Initialise()
    {
        //copy data from the list of clients to a list of players and add the local player
        for (int i = 0; i < clients.Count; i++)
        {
            //generate an array to store resource values
            int[] resources = new int[clients.Count + 1];
            for (int x = 0; x < resources.Length; x++)
            {
                resources[x] = GameConstants.startResourcesPerPlayer * resources.Length;
            }
            players.Add(new Player(clients[i].name, resources));
        }

        //generate an array to store resource values
        int[] resourcesForLastPlayer = new int[clients.Count + 1];
        for (int i = 0; i < resourcesForLastPlayer.Length; i++)
        {
            resourcesForLastPlayer[i] = GameConstants.startResourcesPerPlayer * resourcesForLastPlayer.Length;
        }
        players.Add(new Player(PlayerPrefs.GetString("username"), resourcesForLastPlayer));


        //send the list of players to all the clients
        string[] playerNames = GetPlayers();
        for (int i = 0; i < clients.Count; i++)
        {
            NetworkServer.SendToClient(
                clients[i].id,
                MessageTypes.start,
                new StartMessage(
                    playerNames,
                    clients[i].name,
                    players[i].resources
                )
            );
        }
        gameController = GameObject.Find("_GameMaster").GetComponent<GameController>();
        gameController.Initialise(playerNames, PlayerPrefs.GetString("username"), players[players.Count - 1].resources);


    }

    public string[] GetPlayers()
    {
        string[] output = new string[players.Count];
        for (int i = 0; i < players.Count; i++)
        {
            output[i] = players[i].name;
        }
        return output;
    }

    //--game control
    void FixedUpdate()
    {
        if (isGameStarted  && !isGameOver)
        {
            if (GetReadyStatus())
            {
                ResetReady();
                Trade();
            }
        }
    }

    bool GetReadyStatus()
    {
        bool isEveryoneReady = true;
        for (int i = 0; i < players.Count; i++)
        {
            isEveryoneReady &= players[i].isReady;
        }
        return isEveryoneReady;
    }

    void ResetReady()
    {
        for (int i = 0; i < players.Count; i++)
        {
            players[i].isReady = false;
        }
    }

    void Trade()
    {
        Debug.Log("Trading...");

        for (int i = 0; i < players.Count; i++)
        {
            //give each player their unique resource
            players[i].resources[i] += GameConstants.regularExpenses + (GameConstants.uniqueResourceProductionPerPlayer * (players.Count - 1));

            //subtract all resources
            //Debug.Log(players[i].name + "\n" + "----------------------------------------");
            for (int n = 0; n < players[i].resources.Length; n++)
            {
                /*Debug.Log(
                    players[i].name + " has " + players[i].resources[n] + " of " + ResourceTypes.resources[n] + "\n" +
                    "subtracting 300 of " + ResourceTypes.resources[n] + " from " + players[i].name
                    );*/

                players[i].resources[n] -= GameConstants.regularExpenses;

                /*Debug.Log(
                    players[i].name + " now has " + players[i].resources[n] + " of " + ResourceTypes.resources[n]
                    );
                    */
            }

            //send resources
            for (int n = 0; n < players[i].actualSend.Length; n++)
            {
                /*Debug.Log(
                    players[i].name
                    + " sending "
                    + players[i].actualSend[n]
                    + " of " 
                    + ResourceTypes.resources[i]
                    + " to " 
                    + players[Utils.ActualSendIndexToPlayerIndex(n, Utils.PlayerListToNameArray(players), players[i].name)].name);*/
                players[i].resources[i] -= players[i].actualSend[n];
                players[Utils.ActualSendIndexToPlayerIndex(n, Utils.PlayerListToNameArray(players), players[i].name)].resources[i] 
                    += players[i].actualSend[n];

                players[Utils.ActualSendIndexToPlayerIndex(n, Utils.PlayerListToNameArray(players), players[i].name)].resourcesDelta[i]
                    = players[i].actualSend[n];
            }
        }

        for (int i = 0; i < players.Count; i++)
        {
            for (int n = 0; n < players[i].resources.Length; n++)
            {
                if (players[i].resources[n] < 0)
                {
                    CancelInvoke("Trade");
                    EndGame();
                    return;
                }
            }
        }

        for (int i = 0; i < clients.Count; i++)
        {
            /*for (int x = 0; x < players[i].resourcesDelta.Length; x++)
            {
                Debug.Log(players[i].resourcesDelta[x]);
            }*/
            NetworkServer.SendToClient(clients[i].id, MessageTypes.resources, new Resources(players[i].resources, players[i].resourcesDelta));
        }
        Debug.Log("length:" + players.Count + "\n" + "count - 1: " + (players.Count - 1));
        gameController.UpdateResources(players[players.Count - 1].resources, players[players.Count - 1].resourcesDelta);
    }

    void EndGame()
    {
        isGameOver = true;
        List<string> leaderboard = new List<string>();

        List<Player> playerList = new List<Player>();
        for (int i = 0; i < players.Count; i++)
        {
            playerList.Add(players[i]);
        }

        for (int i = 0; playerList.Count > 0 && i < 8; i++)
        {
            Player max = maxScore(playerList);
            leaderboard.Add(max.name);
            playerList.Remove(max);
        }

        NetworkServer.SendToAll(MessageTypes.end, new EndMessage(leaderboard.ToArray()));
        gameController.End(leaderboard.ToArray());
    }

    Player maxScore(List<Player> playerList)
    {
        if (playerList.Count > 0)
        {
            Player player = playerList[0];
            for (int i = 0; i < playerList.Count; i++)
            {
                if (playerList[i].Score() > player.Score())
                {
                    player = players[i];
                }
            }

            return player;
        }

        return null;
    }

    //--local
    void ClearOffers(string from, string to)
    {
        for (int i = 0; i < offers.Count; i++)
        {
            if (offers[i].player1 == from && offers[i].player2 == to)
            {
                offers.RemoveAt(i);
            }
        }
    }

    void ClearDeals(string player1, string player2)
    {
        for (int i = 0; i < deals.Count; i++)
        {
            if ((deals[i].player1 == player1 || deals[i].player2 == player1) && (deals[i].player1 == player2 || deals[i].player2 == player2))
            {
                deals.RemoveAt(i);
            }
        }
    }

    public void Offer(Deal deal)
    {
        Debug.Log(deal.player1 + " offered " + deal.player1to2 + " for " + deal.player2to1 + " to " + deal.player2);
        ClearOffers(deal.player1, deal.player2);
        offers.Add(deal);
        NetworkServer.SendToAll(MessageTypes.offersUpdate, new DealArray(offers.ToArray()));
    }

    public void Respond(string name, string offerFrom, bool accept)
    {
        if (accept)
        {
            Debug.Log(name + " accepted the deal from " + offerFrom);
            ClearDeals(offerFrom, name);
            Deal offer = GetCurrentOffer(offerFrom, name);
            if (offer.player1to2 != -1)
            {
                deals.Add(offer);
            }
        }
        else
        {
            Debug.Log(name + " denclined the deal from " + offerFrom);
            ClearOffers(offerFrom, name);
        }
        NetworkServer.SendToAll(MessageTypes.offersUpdate, new DealArray(offers.ToArray()));
        NetworkServer.SendToAll(MessageTypes.dealsUpdate, new DealArray(deals.ToArray()));
    }

    public Deal GetCurrentOffer(string from, string to)
    {
        for (int i = 0; i < offers.Count; i++)
        {
            if (offers[i].player1 == from && offers[i].player2 == to)
            {
                return offers[i];
            }
        }
        return new Deal(from, -1, to, -1);
    }

    public Deal GetCurrentDeal(string player1, string player2)
    {
        for (int i = 0; i < deals.Count; i++)
        {
            if ((deals[i].player1 == player1 || deals[i].player2 == player1) && (deals[i].player1 == player2 || deals[i].player2 == player2))
            {
                return deals[i];
            }
        }
        return new Deal(player1, -1, player2, -1);
    }

    public void SetActualSend(string name, int[] array)
    {
        players[FindPlayerByName(name)].actualSend = array;
    }

    public void SetReady(bool isReady, string player)
    {
        Debug.Log(player + " is " + isReady);
        players[FindPlayerByName(player)].isReady = isReady;
    }

    //--network
    void OnOffer(NetworkMessage netMsg)
    {
        Deal deal = netMsg.ReadMessage<Deal>();
        Offer(deal);
    }

    void OnResponse(NetworkMessage netMsg)
    {
        Response response = netMsg.ReadMessage<Response>();
        Respond(FindPlayerName(netMsg.conn.connectionId), response.player, response.accept);
    }

    void OnSetSend(NetworkMessage netMsg)
    {
        ActualSend send = netMsg.ReadMessage<ActualSend>();
        SetActualSend(FindPlayerName(netMsg.conn.connectionId), send.array);
    }

    void OnReady(NetworkMessage netMsg)
    {
        ReadyMessage ready = netMsg.ReadMessage<ReadyMessage>();
        SetReady(ready.isReady, FindPlayerName(netMsg.conn.connectionId));
    }
}
