﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UsernameMaster : MonoBehaviour {

    public InputField input;

    public void OnUsernameSet()
    {
        PlayerPrefs.SetString("username", input.text);
    }

    public void LoadDiscovery()
    {
        Utils.LoadScene("discovery");
    }

    void Start()
    {
        input.text = PlayerPrefs.GetString("username");
    }
}
