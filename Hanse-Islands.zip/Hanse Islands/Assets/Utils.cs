﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Networking;

using System.Collections;
using System.Collections.Generic;

public class Utils : MonoBehaviour{

	public static void LoadScene(string scene)
    {
        SceneManager.LoadScene(scene);
    }

    public static void AddText(Text text, string msg)
    {
        text.text += msg + "\n";
    }

    public static Vector2 AngleToVector(float angle, float magnitude)
    {
        float x = Mathf.Cos(angle);
        float y = Mathf.Sin(angle);
        return new Vector2(x, y) * magnitude;
    }

    public static int PlayerNameToIndex(string playerName, string[] players)
    {
        for (int i = 0; i < players.Length; i++)
        {
            if (playerName == players[i])
            {
                return i;
            }
        }
        return -1;
    }

    public static int PlayerNameToActualSendIndex(string playerName, int[] actualSend, string[] players, string player)
    {
        for (int i = 0; i < actualSend.Length; i++)
        {
            if (ActualSendIndexToPlayerName(i, players, player) == playerName)
            {
                return i;
            }
        }
        return -1;
    }

    public static string ActualSendIndexToPlayerName(int index, string[] players, string player)
    {
        int counter = 0;
        for (int i = 0; i < players.Length; i++)
        {
            if (players[i] != player)
            {
                if (counter == index)
                {
                    return players[i];
                }
                counter++;
            }
        }
        return null;
    }

    public static int ActualSendIndexToPlayerIndex(int index, string[] players, string player)
    {
        for (int i = 0; i < players.Length; i++)
        {
            if (players[i] == ActualSendIndexToPlayerName(index, players, player))
            {
                return i;
            }
        }
        return -1;
    }

    public static string[] PlayerListToNameArray(List<Player> list)
    {
        string[] output = new string[list.Count];
        for (int i = 0; i < list.Count; i++)
        {
            output[i] = list[i].name;
        }
        return output;
    }
}

public class Client
{
    public Client() { }

    public string name;
    public int id;

    public Client(string newName, int newId)
    {
        name = newName;
        id = newId;
    }
}

public class Player
{
    public Player() { }

    public string name;
    public int[] resources;
    public int[] resourcesDelta;
    public int[] actualSend;
    public bool isReady;

    public Player(string newName, int[] newResources)
    {
        name = newName;
        resources = newResources;
        actualSend = new int[resources.Length - 1];
        resourcesDelta = new int[resources.Length];
        isReady = false;
    }

    public int Score()
    {
        int score = 0;
        for (int i = 0; i < resources.Length; i++)
        {
            score += resources[i];
        }
        return score;
    }
}

public class Resources : MessageBase
{
    public Resources() { }

    public int[] resources;
    public int[] resourcesDelta;

    public Resources(int[] newResources, int[] newResourcesDelta)
    {
        resources = newResources;
        resourcesDelta = newResources;
    }
}

public class Deal : MessageBase
{
    public Deal(){ }

    public string player1;
    public int player1to2;

    public string player2;
    public int player2to1;

    public Deal(string newPlayer1, int newPlayer1to2, string newPlayer2, int newPlayer2to1)
    {
        player1 = newPlayer1;
        player1to2 = newPlayer1to2;

        player2 = newPlayer2;
        player2to1 = newPlayer2to1;
    }
}

public class DealArray : MessageBase
{
    public DealArray() { }

    public Deal[] array;

    public DealArray(Deal[] newArray)
    {
        array = newArray;
    }
}

public class ActualSend : MessageBase
{
    public ActualSend() { }

    public int[] array;

    public ActualSend(int[] newArray)
    {
        array = newArray;
    }
}

public class Response : MessageBase
{
    public Response() { }

    public string player;
    public bool accept;

    public Response(string newPlayer, bool newAccept)
    {
        player = newPlayer;
        accept = newAccept;
    }
}

public static class ResourceTypes
{
    public static readonly string[] resources = {
        "food",
        "water",
        "wood",
        "iron",
        "stone",
        "gold",
        "oxygen",
        "knowledge"
    };
}

public static class GameConstants
{
    public static int regularExpenses = 200;
    public static int uniqueResourceProductionPerPlayer = 100;
    public static int startResourcesPerPlayer = 200;

    public static float roundLengthInSeconds = 30;
}

public class TextMessage : MessageBase
{
    public TextMessage() { }

    public string text;

    public TextMessage(string newText)
    {
        text = newText;
    }
}

public class ReadyMessage : MessageBase
{
    public ReadyMessage() { }

    public bool isReady;

    public ReadyMessage(bool newIsReady)
    {
        isReady = newIsReady;
    }
}

public class StartMessage : MessageBase
{
    public StartMessage() { }

    public string[] players;
    public string player;
    public int[] resources;

    public StartMessage(string[] newPlayers, string newPlayer, int[] newResources)
    {
        players = newPlayers;
        player = newPlayer;
        resources = newResources;
    }

}

public class EndMessage : MessageBase
{
    public EndMessage() { }

    public string[] players;

    public EndMessage(string[] newPlayers)
    {
        players = newPlayers;
    }

}

public class ClientMessage : MessageBase
{
    public ClientMessage() { }

    public string name;

    public ClientMessage(string newName)
    {
        name = newName;
    }
}

public static class MessageTypes
{
    public const short text = MsgType.Highest + 1;
    public const short setup = MsgType.Highest + 2;
    public const short deal = MsgType.Highest + 3;
    public const short start = MsgType.Highest + 4;
    public const short response = MsgType.Highest + 5;
    public const short actualSend = MsgType.Highest + 6;
    public const short offersUpdate = MsgType.Highest + 7;
    public const short dealsUpdate = MsgType.Highest + 8;
    public const short resources = MsgType.Highest + 9;
    public const short end = MsgType.Highest + 10;
    public const short ready = MsgType.Highest + 11;
}
